"""Direct Festival Lead competition entry point."""

import os

os.environ["PTCG_DIPPLIN_SEARCH"] = "0"

from ptcg_ai.dipplin.policy import DipplinCompetitionAgent

_AGENT = DipplinCompetitionAgent()


def agent(obs_dict: dict) -> list[int]:
    return _AGENT(obs_dict)
