"""Direct Festival Lead competition entry point."""

import os

os.environ["PTCG_DIPPLIN_SEARCH"] = "1"
os.environ["PTCG_DIPPLIN_SECOND_OPENING_V2"] = "1"
os.environ["PTCG_DIPPLIN_GO_FIRST"] = "1"
os.environ["PTCG_DIPPLIN_ROUTE_V2"] = "0"
os.environ["PTCG_DIPPLIN_WORLDS"] = "2"

from ptcg_ai.dipplin.policy import DipplinCompetitionAgent

_AGENT = DipplinCompetitionAgent()


def agent(obs_dict: dict) -> list[int]:
    return _AGENT(obs_dict)
