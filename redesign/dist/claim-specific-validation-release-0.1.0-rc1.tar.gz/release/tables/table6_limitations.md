| scope | status | limitation |
| --- | --- | --- |
| M10_method_storage | PARTIAL_SYSTEM_ARTIFACT_ONLY | Artifact bytes retained; per-method bundle bytes absent. |
| M13_cross_system | COMPLETE_WITH_TWO_SYSTEM_LIMITATION | See analysis output. |
| M4_coverage | NOT_ESTIMABLE_AS_PREDECLARED | Runner retained no A/A mirror/equal-temperature banks and no construction-fixed effects; emitted centered empirical-bootstrap diagnostic is not confirmatory coverage. |
| M5_typeI | NOT_ESTIMABLE_AS_PREDECLARED | No stored known-zero A/A outcome pairs; centered empirical-bootstrap diagnostic is labeled post-freeze proxy. |
| M6_power | PARTIAL_DIAGNOSTIC_ONLY | Alternative outcomes exist, but frozen N=80 subsampling without replacement is impossible from N=40 and no fixed-effect construction was stored; replacement bootstrap reported. |
| M7_variance | CONFIRMATORY_COMPLETE_WITH_DECLARED_SHARED_BANK_LIMITATION | outcome-pair rows |
| M8_conclusion_changes | EXPLORATORY_COMPLETE | paired-vs-Welch bootstrap |
| M9_method_runtime | NOT_ESTIMABLE_FROM_RAW_SCHEMA | No per-method acquisition or classifier timers were retained. |
| holdem | SYSTEM_BOUNDARY | limit-holdem betting legality independent of cards simplifies some dynamics; young API stability |
| ising | SYSTEM_BOUNDARY | pure-python path used for draw transparency (~slower); critical slowing down near Tc limits equilibrium claims; study compares fixed-budget observables only |
| benchmark | IMPLEMENTATION_FINDING | Ising S4/S8 mechanics did not inject intended clock residual randomness; Branch-C detection is a wrapper-validity finding, not natural-failure prevalence. |
| historical case | MOTIVATION_ONLY | Restricted assets, retrospective rules, and no semantic event alignment; never pooled with prospective evidence. |
