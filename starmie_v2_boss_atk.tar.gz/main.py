"""Submission entry point for the PTCG AI Battle Challenge.

Contract (from cg/api.py / cabt.py):
  agent(obs_dict) -> list[int]
    - If obs_dict["select"] is None -> return the 60-card deck (list of card IDs).
    - Else return option indices, len in [minCount, maxCount], no duplicates,
      each in [0, len(option)).

Must never crash and must respond well within the time budget, or it loses.
We deliberately work on the raw dict (no cg.api import) so the decision logic
is import-safe on any platform; the engine itself is provided by the runtime.
"""
import os
import random

from agent import policy
from agent import search

_DECK_CACHE: list[int] | None = None
_RNG = random.Random(12345)


# NOTE: Kaggle loads this file via exec() WITHOUT defining __file__, so guard it.
try:
    _HERE = os.path.dirname(os.path.abspath(__file__))
except NameError:
    _HERE = "/kaggle_simulations/agent"


def _deck_path() -> str:
    for p in (
        "deck.csv",
        os.path.join(_HERE, "deck.csv"),
        "/kaggle_simulations/agent/deck.csv",
    ):
        if os.path.exists(p):
            return p
    return "deck.csv"


def read_deck_csv() -> list[int]:
    global _DECK_CACHE
    if _DECK_CACHE is not None:
        return _DECK_CACHE
    with open(_deck_path(), "r") as f:
        rows = [r.strip() for r in f.read().splitlines() if r.strip() != ""]
    deck = [int(rows[i]) for i in range(60)]
    _DECK_CACHE = deck
    return deck


def _legal_fallback(select: dict) -> list[int]:
    """Guaranteed-legal selection if everything else fails."""
    n = len(select.get("option", []))
    mn = max(select.get("minCount", 1), 0)
    k = min(max(mn, 1), n) if n else 0
    return list(range(k))


def decide(obs_dict: dict, deck: list[int]) -> list[int]:
    """Core decision for a given deck. (Deck is a parameter so we can A/B test
    different decks with the same brain in local self-play.)"""
    select = obs_dict.get("select")
    if select is None:
        return deck
    try:
        # Prefer search on branching MAIN decisions; heuristic for the rest.
        choice = None
        if search.ENABLED:
            choice = search.choose_action(obs_dict, deck, _RNG)
        if choice is None:
            choice = policy.choose(obs_dict)
        # Validate before returning; fall back if the policy produced garbage.
        n = len(select["option"])
        mn, mx = select.get("minCount", 1), select.get("maxCount", 1)
        ok = (
            isinstance(choice, list)
            and all(isinstance(i, int) and 0 <= i < n for i in choice)
            and len(set(choice)) == len(choice)
            and mn <= len(choice) <= mx
        )
        if ok:
            return choice
    except Exception:
        pass
    return _legal_fallback(select)


def agent(obs_dict: dict) -> list[int]:
    return decide(obs_dict, read_deck_csv())
