"""Phase-1 heuristic policy. Operates on the raw obs dict (no engine import),
so it is unit-testable on macOS. Goal: reliably beat the random agent without
ever returning an illegal move or timing out.

Decision philosophy (greedy, terminating):
  - On the MAIN menu: do cheap setup (attach energy, evolve, play, ability),
    then ATTACK for max damage (attacking ends the turn -> guarantees progress).
  - For sub-selections: sensible context-specific defaults.
  - Anything unrecognized -> a guaranteed-legal fallback.

Everything is intentionally simple; Phase 2 replaces this with determinized
MCTS using the engine's search_begin/step API.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache

from . import card_db

# Test-only: POLICY_LEGACY=1 reproduces the pre-fix brain (flat attack values,
# no bench cap) so we can A/B the bug fixes against the old behavior.
_LEGACY = bool(os.environ.get("POLICY_LEGACY"))


@lru_cache(maxsize=1)
def _attack_db() -> dict[int, int]:
    """attackId -> attack value (max of engine static damage and CSV-parsed base,
    so effect/multiplier attacks aren't valued at 0). Baked by build_attack_db.py.
    In legacy mode, multiplier attacks fall back to their bare base (the bug)."""
    here = os.path.dirname(os.path.abspath(__file__))
    for p in (os.path.join(here, "attack_db.json"),
              "/kaggle_simulations/agent/agent/attack_db.json"):
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                raw = json.load(f)
            if _LEGACY:
                return {int(k): max(int(v.get("damage", 0)), int(v.get("base", 0)))
                        for k, v in raw.items()}
            return {int(k): int(v.get("value", v.get("damage", 0)))
                    for k, v in raw.items()}
    return {}


@lru_cache(maxsize=1)
def _attack_cost_db() -> dict[int, int]:
    """attackId -> number of Energy in its cost (for the energy tie-break: among
    similar-value attacks, prefer the cheaper one so we can attack sooner)."""
    here = os.path.dirname(os.path.abspath(__file__))
    for p in (os.path.join(here, "attack_db.json"),
              "/kaggle_simulations/agent/agent/attack_db.json"):
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                raw = json.load(f)
            return {int(k): len(v.get("energies") or []) for k, v in raw.items()}
    return {}


def _attack_cost(opt: dict) -> int:
    aid = opt.get("attackId")
    if aid is not None:
        c = _attack_cost_db().get(int(aid))
        if c is not None:
            return c
    return len(opt.get("cost") or "")

# --- mirrored from cg/api.py (kept in sync manually) ---------------------------

class SelectType:
    MAIN = 0
    CARD = 1
    ATTACHED_CARD = 2
    CARD_OR_ATTACHED_CARD = 3
    ENERGY = 4
    SKILL = 5
    ATTACK = 6
    EVOLVE = 7
    COUNT = 8
    YES_NO = 9
    SPECIAL_CONDITION = 10


class OptionType:
    NUMBER = 0
    YES = 1
    NO = 2
    CARD = 3
    TOOL_CARD = 4
    ENERGY_CARD = 5
    ENERGY = 6
    PLAY = 7
    ATTACH = 8
    EVOLVE = 9
    ABILITY = 10
    DISCARD = 11
    RETREAT = 12
    ATTACK = 13
    END = 14
    SKILL = 15
    SPECIAL_CONDITION = 16


class Ctx:
    IS_FIRST = 41
    MULLIGAN = 42
    ACTIVATE = 43
    FIRST_EFFECT = 44
    MORE_DEVOLVE = 45
    COIN_HEAD = 46

# Contexts where we want to KEEP/give up as little as possible -> choose minCount.
_MIN_CONTEXTS = {8, 9, 10, 20, 23, 26, 27, 29, 30, 32}  # discard / to-deck / detach / devolve
# Contexts where MORE is better -> choose maxCount (draw, damage, heal, place counters).
_MAX_CONTEXTS = {13, 14, 15, 17, 38, 39}

# MAIN action priority: lower number = do earlier in the turn.
_MAIN_PRIORITY = {
    OptionType.ABILITY: 0,
    OptionType.ATTACH: 1,
    OptionType.EVOLVE: 2,
    OptionType.PLAY: 3,
    OptionType.ATTACK: 4,   # ends the turn -> after setup
    OptionType.RETREAT: 5,
    OptionType.END: 9,      # only when nothing else
}

_LOOP_GUARD = 60  # if a turn drags on this long, stop futzing and attack/end


def choose(obs: dict) -> list[int]:
    """Return the list of selected option indices for this obs."""
    select = obs.get("select")
    if select is None:
        raise ValueError("choose() called with select=None (deck phase handled in main)")

    options = select["option"]
    n = len(options)
    mn = select.get("minCount", 1)
    mx = select.get("maxCount", 1)
    stype = select.get("type")
    ctx = select.get("context")
    state = obs.get("current") or {}

    try:
        if stype == SelectType.MAIN:
            return [_choose_main(options, state)]
        if stype == SelectType.ATTACK:
            return [_best_attack(options)]
        if stype == SelectType.YES_NO:
            return [_choose_yes_no(options, ctx)]
        if stype == SelectType.COUNT:
            return [_choose_count(options, ctx)]
        if stype == SelectType.CARD:
            return _choose_cards(options, state, ctx, mn, mx)
    except Exception:
        pass  # never crash -> fall through to the safe fallback

    return _fallback(n, mn, mx, ctx)


# --- MAIN menu -----------------------------------------------------------------

# Stop benching once we hold this many Pokémon: more than this just floods the
# board with the wrong Pokémon and hands an aggressive opponent free KO targets.
_BENCH_TARGET = 3


def _my_bench_count(state: dict) -> int:
    players = state.get("players")
    yi = state.get("yourIndex")
    if players is None or yi is None:
        return 0
    try:
        return len(players[yi].get("bench") or [])
    except (IndexError, TypeError, KeyError):
        return 0


def _choose_main(options: list[dict], state: dict) -> int:
    action_count = state.get("turnActionCount", 0)
    force_finish = action_count >= _LOOP_GUARD
    bench_n = _my_bench_count(state)

    best_idx, best_key = 0, None
    for i, opt in enumerate(options):
        t = opt.get("type")
        if force_finish and t not in (OptionType.ATTACK, OptionType.END):
            continue
        prio = _MAIN_PRIORITY.get(t, 7)
        tiebreak = (0, 0)
        if t == OptionType.ATTACK:
            # prefer higher damage, then cheaper energy cost (attack sooner).
            tiebreak = (-_attack_damage(opt), _attack_cost(opt))
        elif t == OptionType.PLAY and not _LEGACY:
            # Bench discipline: once the bench is stocked, stop benching so ATTACK
            # (prio 4) wins instead. And prefer benching an evolution basic
            # (e.g. Snover) over a terminal one (e.g. Kyogre).
            if bench_n >= _BENCH_TARGET:
                prio = 8  # below ATTACK / RETREAT
            cid = opt.get("cardId") or 0
            tiebreak = (0 if card_db.evolvable(cid) else 1, 0)
        key = (prio, tiebreak[0], tiebreak[1], i)
        if best_key is None or key < best_key:
            best_key, best_idx = key, i
    return best_idx


# --- attacks -------------------------------------------------------------------

def _attack_damage(opt: dict) -> int:
    """Damage for an ATTACK option, via the baked attackId->damage map.

    Falls back to an inline 'damage' field (used by tests) or 0 when the map
    is absent (e.g. before build_attack_db.py has been run in-container).
    """
    aid = opt.get("attackId")
    if aid is not None:
        dmg = _attack_db().get(int(aid))
        if dmg is not None:
            return dmg
    return int(opt.get("damage") or 0)


def _best_attack(options: list[dict]) -> int:
    # Rank by damage desc, then energy cost asc (cheaper attack of equal value).
    best_idx, best_key = 0, None
    for i, opt in enumerate(options):
        key = (-_attack_damage(opt), _attack_cost(opt), i)
        if best_key is None or key < best_key:
            best_key, best_idx = key, i
    return best_idx


# --- yes/no --------------------------------------------------------------------

def _choose_yes_no(options: list[dict], ctx: int) -> int:
    # Map desired YES/NO to an option index.
    def find(t):
        for i, o in enumerate(options):
            if o.get("type") == t:
                return i
        return 0

    if ctx == Ctx.IS_FIRST:
        return find(OptionType.NO)      # prefer going second
    if ctx == Ctx.MULLIGAN:
        return find(OptionType.NO)      # keep our hand
    if ctx in (Ctx.ACTIVATE, Ctx.FIRST_EFFECT):
        return find(OptionType.YES)     # activate beneficial effects
    return find(OptionType.YES)


# --- counts --------------------------------------------------------------------

def _choose_count(options: list[dict], ctx: int) -> int:
    # Options are NUMBER; pick the largest (draw/place more) by default.
    best_idx, best_n = 0, None
    for i, o in enumerate(options):
        v = o.get("number", 0) or 0
        if best_n is None or v > best_n:
            best_n, best_idx = v, i
    return best_idx


# --- card selections -----------------------------------------------------------

def _choose_cards(options: list[dict], state: dict, ctx: int, mn: int, mx: int) -> list[int]:
    # For "put into play / active" pick highest-HP Pokémon; otherwise default.
    if ctx in (1, 2, 4, 5, 6):  # SETUP_ACTIVE, SETUP_BENCH, TO_ACTIVE, TO_BENCH, TO_FIELD
        if ctx == 4 and options:  # TO_ACTIVE: Boss target vs switch-in need opposite logic
            my_idx = (state or {}).get("yourIndex", 0)
            players = (state or {}).get("players") or []
            pi = options[0].get("playerIndex")
            if pi is not None and pi != my_idx:
                # Boss Orders target (opp's bench): prefer lowest remaining HP for cheap KO.
                # Before this fix, we sorted by -hp (highest HP first) which actively picked
                # their tankiest mon — exactly wrong. Now pick the most damaged/weakest target.
                opp_bench = players[pi].get("bench") or [] if pi < len(players) else []

                def _boss_score(i: int) -> int:
                    slot = options[i].get("index") or 0
                    mon = opp_bench[slot] if slot < len(opp_bench) else None
                    return (mon or {}).get("hp", 9999)  # lowest remaining HP first

                ranked = sorted(range(len(options)), key=_boss_score)
                return sorted(ranked[:max(mn, 1)])
            # Our switch-in: prefer energized attacker, avoid weakness, then highest max HP.
            my_bench = players[my_idx].get("bench") or [] if my_idx < len(players) else []
            opp_active = (players[1 - my_idx].get("active") or [None])[0] if 1 - my_idx < len(players) else None
            opp_type = card_db.pokemon_type((opp_active or {}).get("id") or 0)

            def _switch_score(i: int) -> tuple:
                slot = options[i].get("index") or 0
                mon = my_bench[slot] if slot < len(my_bench) else None
                mon_id = (mon or {}).get("id", 0)
                energy = len((mon or {}).get("energyCards") or []) if mon else 0
                max_hp = (mon or {}).get("maxHp", 0)
                # Penalize switching in a mon weak to the opponent's type (takes 30 extra dmg).
                weak = opp_type and card_db.weakness(mon_id) == opp_type
                return (int(weak), -energy, -max_hp)  # avoid weakness, most energy, most HP

            ranked = sorted(range(len(options)), key=_switch_score)
            return sorted(ranked[:max(mn, 1)])
        ranked = sorted(
            range(len(options)),
            key=lambda i: -card_db.hp(options[i].get("cardId") or 0),
        )
        k = max(mn, 1)
        return sorted(ranked[:k])
    return _fallback(len(options), mn, mx, ctx)


# --- generic fallback ----------------------------------------------------------

def _fallback(n: int, mn: int, mx: int, ctx: int) -> list[int]:
    n = max(n, 0)
    if n == 0:
        return []
    if ctx in _MAX_CONTEXTS:
        k = mx
    elif ctx in _MIN_CONTEXTS:
        k = mn
    else:
        k = mn if mn > 0 else 1
    k = max(0, min(k, n))
    return list(range(k))
