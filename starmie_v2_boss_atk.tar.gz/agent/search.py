"""Phase-2 search: use the engine forward model (search_begin/step) to evaluate
candidate actions by simulating them, instead of trusting a static heuristic.

Imports cg.api, so it ONLY works where the engine loads (Linux container / Kaggle).
On macOS this module raises on import of cg; callers must guard with ENABLED.
"""
from __future__ import annotations

import os
import random
import time
from collections import Counter
from dataclasses import asdict

try:
    from cg.api import (search_begin, search_step, search_end, search_release,
                        to_observation_class)
    ENABLED = True
except Exception:  # noqa: BLE001 - no engine on this platform
    ENABLED = False

from . import card_db
from . import policy

# Search budget knobs (kept conservative; Kaggle runs natively so this is plenty).
PLY_CAP = 60           # max simulated plies per rollout (our turn + opp reply)
MAX_BRANCH = 8         # top-level options to evaluate per decision
DETERMINIZATIONS = 3   # imagined opponents averaged per decision (variance control)
MOVE_BUDGET_S = 3.0    # soft wall-clock budget per searched decision

# Card ids for KO-readiness shaping (the Trevenant combo pieces).
# Starmie/Froslass hero config: both Mega ex are 1-energy attackers (Mega Starmie ex
# Jetting Blow 1{W}=120+50 snipe; Mega Froslass ex Resentful Refrain 1{W}=50x hand).
_ATTACKERS = (1031, 861, 666)   # Mega Starmie ex, Mega Froslass ex, Cinderace
# 666/861 are INERT when not in play, so this one config A/Bs both decks: v1 (Froslass,
# no 666) behaves identically; the Cinderace meta shell (no Froslass) gets 666 valued.
# Cinderace = energy engine: Turbo Flare loads 3 Basic Energy to bench -> ramp Mega Starmie
# to its 3-energy Nebula Beam (210). _ENGINE rewards keeping Cinderace deployed/active.
_ENGINE = 666
# Set per-game in choose_action: True when 666 is in our deck (the Cinderace ramp shell).
# Flips value()'s energy-readiness from the v1 tempo plan (1 energy = payoff) to the ramp
# plan (3 energy on Mega Starmie = Nebula Beam payoff). False -> v1 behaves identically.
_IS_RAMP = False
# Heroes that WIN by staying alive (tank+heal+snipe), unlike Trevenant which wants its
# mons KO'd. value() rewards keeping these healthy. Empty-equivalent on a Trev board
# (these ids aren't in play there), so the survival term auto-disables for that build.
_SURVIVE_IDS = (1031, 861)   # Mega Starmie ex, Mega Froslass ex
# Weight for the attacker-survival term. Env-tunable for gauntlet A/B/sweep; 0 = the
# old Trev-blind brain (clean baseline). Default 140: confirmed best in a 24-game/opp
# sweep -- lifts the real-meta matchups (Hop's Snorlax 91->100, Mega Lucario 45->58,
# Alakazam 45->54); only regresses Abomasnow (turtle-vs-heal-wall), which is ~0% of the
# real meta. ponytail: env knob mirrors NO_LETHAL/SEARCH_DEBUG.
_SURVIVE_W = float(os.environ.get("SURVIVE_W", "140"))


def _prize_value(pid: int) -> int:
    """Prizes the opponent gives up when this Pokemon is KO'd: Mega ex=3, ex=2, else 1."""
    c = card_db.card(pid) or {}
    rule = (c.get("rule") or "").lower()
    if "ex" in rule:
        return 3 if "mega" in rule else 2
    return 1

# Diagnostics (inspected by scripts/diag_search.py).
STATS = {"calls": 0, "not_main": 0, "begin_none": 0, "begin_raise": 0,
         "searched": 0, "rollout_steps": 0, "step_raise": 0, "last_err": ""}

# A generic legal filler for opponent hidden cards: a basic Pokémon + basic energy.
# (Card 3 = Basic Water Energy; we pick a cheap Basic Pokémon id for the "needs a
# basic" constraint.)  These only stand in for *unknown* cards.
_BASIC_ENERGY = 3
_FILLER_BASIC_POKEMON = 722  # Snover (a Basic Pokémon present in the pool)


def _basic_pokemon_ids(sample: int = 1) -> list[int]:
    out = []
    for cid, c in card_db.db().items():
        if c.get("stage_or_type") == "Basic Pokémon":
            out.append(cid)
            if len(out) >= sample:
                break
    return out or [_FILLER_BASIC_POKEMON]


def _known_my_cards(ps: dict) -> list[int]:
    """Card IDs we can see among our own non-deck, non-prize locations."""
    ids: list[int] = []
    for p in (ps.get("active") or []):
        if p:
            ids.append(p["id"])
            for e in p.get("energyCards", []):
                ids.append(e["id"])
            for t in p.get("tools", []):
                ids.append(t["id"])
            for pe in p.get("preEvolution", []):
                ids.append(pe["id"])
    for p in ps.get("bench", []):
        ids.append(p["id"])
        for e in p.get("energyCards", []):
            ids.append(e["id"])
        for t in p.get("tools", []):
            ids.append(t["id"])
        for pe in p.get("preEvolution", []):
            ids.append(pe["id"])
    for c in (ps.get("hand") or []):
        ids.append(c["id"])
    for c in ps.get("discard", []):
        ids.append(c["id"])
    return ids


def determinize(obs: dict, full_deck: list[int], rng: random.Random):
    """Build the hidden-info arguments for search_begin from a real obs.

    Returns kwargs dict for search_begin, or None if we cannot (e.g. deck phase).
    """
    state = obs.get("current")
    if state is None:
        return None
    me = state["yourIndex"]
    my = state["players"][me]
    opp = state["players"][1 - me]

    # --- our deck + prize split: full deck minus everything we can see ---
    known = _known_my_cards(my)
    pool = list(full_deck)
    for cid in known:
        if cid in pool:
            pool.remove(cid)
    rng.shuffle(pool)
    deck_n = my["deckCount"]
    prize_n = len(my["prize"])
    # If counts don't line up (effects, special energies), pad/truncate with energy.
    while len(pool) < deck_n + prize_n:
        pool.append(_BASIC_ENERGY)

    # Prize-aware split (the 1250-Starmie lesson). A search card (Petrel / Pokegear /
    # Hop's Bag) can reveal our WHOLE deck; when it does we know the deck exactly, so
    # everything else in `pool` is prized -> pin it OUT of your_deck. Otherwise the
    # engine's forward search can assemble a "lethal" on a card that's actually under
    # a prize and then fizzle in the real game (a NOMATCH). Random split only when we
    # genuinely can't tell.
    sel = obs.get("select") or {}
    revealed = sel.get("deck")
    if revealed is not None and len(revealed) == deck_n:
        your_deck = [c["id"] for c in revealed if c]
        rng.shuffle(your_deck)                       # order re-randomizes after a search
        rem = Counter(pool); rem.subtract(Counter(your_deck))
        your_prize = list(Counter({k: v for k, v in rem.items() if v > 0}).elements())
        while len(your_prize) < prize_n:             # visible-zone accounting drift
            your_prize.append(_BASIC_ENERGY)
        your_prize = your_prize[:prize_n]
    else:
        your_deck = pool[:deck_n]
        your_prize = pool[deck_n:deck_n + prize_n]

    # --- opponent: contents unknown. Prior = "they play like us" (mirror our
    # deck list), minus whatever of theirs we can already see. Far more realistic
    # than an all-energy strawman, so rollouts reflect real play. ---
    opp_deck_n = opp["deckCount"]
    opp_prize_n = len(opp["prize"])
    opp_hand_n = opp["handCount"]
    opp_visible = _known_my_cards(opp)  # their face-up cards (in play / discard)
    opp_pool = list(full_deck)
    for cid in opp_visible:
        if cid in opp_pool:
            opp_pool.remove(cid)
    rng.shuffle(opp_pool)
    need = opp_deck_n + opp_prize_n + opp_hand_n
    basics = _basic_pokemon_ids(3)
    # Ensure at least one Basic Pokémon among the opponent's hidden cards (setup rule).
    if opp_pool and not any(card_db.card(c) and
                            card_db.card(c).get("stage_or_type") == "Basic Pokémon"
                            for c in opp_pool[:need]):
        opp_pool.insert(0, basics[0])
    while len(opp_pool) < need:
        opp_pool.append(_BASIC_ENERGY)
    opponent_deck = opp_pool[:opp_deck_n]
    opponent_prize = opp_pool[opp_deck_n:opp_deck_n + opp_prize_n]
    opponent_hand = opp_pool[opp_deck_n + opp_prize_n:need]

    # opponent active only needed when it is face-down (unknown) to us
    opp_active = opp.get("active") or []
    opponent_active = [basics[0]] if (len(opp_active) > 0 and opp_active[0] is None) else []

    return dict(
        your_deck=your_deck,
        your_prize=your_prize,
        opponent_deck=opponent_deck,
        opponent_prize=opponent_prize,
        opponent_hand=opponent_hand,
        opponent_active=opponent_active,
    )


def begin(obs: dict, full_deck: list[int], rng: random.Random):
    """search_begin with a determinization. Returns root SearchState or None."""
    if not ENABLED:
        return None
    kw = determinize(obs, full_deck, rng)
    if kw is None:
        return None
    obs_cls = to_observation_class(obs)
    return search_begin(obs_cls, **kw)


def value(state_obs, me: int) -> float:
    """Trevenant-tuned heuristic value from player `me`'s perspective.

    vs the legacy Abomasnow value this replaces:
      - Prizes dominate (taking a prize >> any board consideration).
      - Offense = prize-weighted damage on the OPPONENT's ACTIVE only, as a
        fraction of its max HP. This lets search reward the big Horrifying Revenge
        swing (a triggered 130 spikes the fraction) and prefer SETUP when the
        trigger isn't live -- the engine computes the real conditional damage
        during simulation, so we never hardcode it.
      - NO reward for our own board HP. Trevenant WANTS its Hop's mons KO'd to arm
        the 130; the legacy board_hp term punished exactly that, fighting the deck.
      - Deck-out penalty so search never durdles/self-mills out (model45's #1 loss),
        plus mild pressure to deck the OPPONENT (stall/control mirror).
      - Survival: an empty bench means one KO = instant loss.
    """
    state = state_obs.current
    if state is None:
        return 0.0
    if state.result == me:
        return 1e6
    if state.result == (1 - me):
        return -1e6
    if state.result == 2:
        return 0.0
    my = state.players[me]
    opp = state.players[1 - me]

    # Prizes (dominant): fewer of OUR prizes remaining = closer to winning.
    prize_term = len(opp.prize) - len(my.prize)

    # Offensive progress: prize-weighted damage on the opponent's Active (0..~3).
    ko_term = 0.0
    for p in (opp.active or []):
        if p and p.maxHp > 0:
            ko_term += ((p.maxHp - p.hp) / p.maxHp) * _prize_value(p.id)

    # Survival: empty bench = one KO from losing (cost us our first ladder game).
    has_active = len([p for p in (my.active or []) if p]) > 0
    my_bench = len(my.bench)
    survival = -400.0 if (has_active and my_bench == 0) else 0.0
    survival += 40.0 * min(my_bench, 3)

    # Deck-out: starting a turn with 0 deck cards is a LOSS. Cheap until it gets
    # dangerous, then steep -> search closes instead of milling itself out.
    deckout = -20.0 * max(0, 9 - my.deckCount) if my.deckCount <= 8 else 0.0
    opp_deckout = 6.0 * max(0, 9 - opp.deckCount) if opp.deckCount <= 8 else 0.0

    # KO-readiness (deck-specific seam): reward the END STATE of the game plan and let
    # search find the moves. The FIRST energy on a Mega ex is the payoff -- it turns the
    # 330hp body into a real weapon (Jetting Blow, 1 {W} = 120 + 50 snipe), the line that
    # actually wins; energy 2/3 only upgrade to Nebula Beam (210), marginal. Kept small
    # vs prize/KO so it only breaks ties toward setup.
    # Ramp shell (Cinderace, _IS_RAMP): Mega Starmie's win line is the 3-energy Nebula Beam
    # (210, ignores everything), so the 2nd/3rd energy ARE the payoff -> reward ramping to 3.
    # Cinderace itself needs only 1 energy (Turbo Flare) -> never reward over-loading it.
    in_play = [p for p in (my.active or []) if p] + list(my.bench)
    active_ids = {p.id for p in (my.active or []) if p}
    ready = 0.0
    for p in in_play:
        if p.id in _ATTACKERS:
            e = len(p.energyCards)
            ready += 50.0 if e >= 1 else 0.0
            if _IS_RAMP and p.id == 1031:
                ready += 30.0 * min(max(e - 1, 0), 2)   # ramp Mega Starmie to Nebula Beam
            elif p.id != _ENGINE:
                ready += 12.0 * min(max(e - 1, 0), 2)   # tempo: 2nd/3rd energy marginal
    if _ENGINE in active_ids:
        ready += 25.0
    elif any(p.id == _ENGINE for p in in_play):
        ready += 10.0
    # Spread payoff: Jetting Blow banks 50 on the opp BENCH, which ko_term (active only)
    # can't see -- reward prize-weighted bench damage too, capped well below a prize.
    opp_bench_dmg = 0.0
    for p in opp.bench:
        if p and p.maxHp > 0:
            opp_bench_dmg += ((p.maxHp - p.hp) / p.maxHp) * _prize_value(p.id)
    ready += 30.0 * min(opp_bench_dmg, 2.0)

    # Attacker survival (Starmie seam): Starmie WINS by keeping its 330HP Mega ex alive
    # -- tank a hit, heal with Wally's (full heal + energy back to hand), snipe again.
    # The Trev-tuned value is blind to our HP, so search never values healing/retreating
    # a hurt attacker -> coin-flips the aggro matchups (Mega Lucario/Alakazam at 50%).
    # Reward our ACTIVE attacker's HP fraction. ACTIVE-only (not bench) so it never trades
    # attacking for passive hiding; small vs prize(1000)/ko(200) so it preserves the snipe
    # engine without durdling. Gated to _SURVIVE_IDS -> zero effect on the Trev build.
    attacker_hp = 0.0
    if _SURVIVE_W:
        for p in (my.active or []):
            if p and p.id in _SURVIVE_IDS and p.maxHp > 0:
                attacker_hp += _SURVIVE_W * (p.hp / p.maxHp)

    # Prize-race aggression: when BEHIND (more of our prizes left than theirs),
    # up-weight KO-progress so search gambles for the catch-up KO instead of
    # durdling -- directly targets the out-survive/under-convert loss pattern.
    behind = max(0, len(my.prize) - len(opp.prize))
    desperation = 1.0 + 0.4 * behind

    # Attrition / deck-out race -- a GENERAL second win condition, not a per-deck
    # counter. When the prize race STALLS (a wall we can't out-damage, a grind), the
    # game is decided by who decks out last, so reward our deck-count advantage,
    # ramped up the more stalled the race is. This is the abstract answer to
    # heal-walls/high-HP decks (seen or unseen): reason about the race, not the
    # opponent's identity. Off during an active prize race (don't fight tempo).
    prizes_off = (6 - len(my.prize)) + (6 - len(opp.prize))
    grind = max(0.0, 1.0 - prizes_off / 6.0)        # 1.0 when nobody's scoring, 0 by 6 prizes
    attrition = 5.0 * grind * (my.deckCount - opp.deckCount)

    return (1000.0 * prize_term
            + 200.0 * ko_term * desperation
            + ready
            + attacker_hp
            + survival
            + deckout
            + opp_deckout
            + attrition)


def _rollout(state, me: int, deadline: float) -> float:
    """Finish OUR turn, then play out the OPPONENT's reply (both via heuristic),
    and score the board once control returns to us. Including their counter-punch
    is what lets search prefer moves that don't expose us to a return-KO -- the
    thing a greedy 'max damage now' heuristic can't see. Horizon is short (~2
    turns), so determinization noise stays small relative to the tactical signal."""
    steps = 0
    seen_opp = False
    while steps < PLY_CAP:
        cur = state.observation.current
        if cur is None or cur.result >= 0:
            break
        if cur.yourIndex != me:
            seen_opp = True
        elif seen_opp:                 # back to our turn -> opponent has replied
            break
        obs_d = asdict(state.observation)
        if obs_d.get("select") is None:
            break
        try:
            choice = policy.choose(obs_d)
            # Rollout opponent: attack-first (real top agents always attack when they can;
            # the setup-first heuristic lets them durrdle, hiding the return-KO danger).
            if (cur.yourIndex != me
                    and obs_d.get("select", {}).get("type") == policy.SelectType.MAIN):
                sel_opts = obs_d["select"]["option"]
                _adb = policy._attack_db() or {}
                for i, o in enumerate(sel_opts):
                    if o.get("type") == policy.OptionType.ATTACK:
                        aid = o.get("attackId")
                        if aid is not None and _adb.get(int(aid), 0) > 0:
                            choice = [i]
                            break
            state = search_step(state.searchId, choice)
        except Exception as e:  # noqa: BLE001 - bail out, score what we have
            STATS["step_raise"] += 1
            STATS["last_err"] = f"rollout {type(e).__name__}: {e}"
            break
        steps += 1
        STATS["rollout_steps"] += 1
        if time.monotonic() > deadline:
            break
    return value(state.observation, me)


LETHAL_BRANCH = 6      # options explored per node in the lethal DFS
LETHAL_NODES = 160     # node budget per lethal probe (bounds worst-case cost)


def _find_lethal(state, me: int, deadline: float, budget: list) -> bool:
    """True if a sequence of OUR moves from `state` wins THIS turn (reaches
    result==me before the turn passes). A focused DFS that BRANCHES over our MAIN
    options (vs _rollout's single heuristic line) so it actually finds the
    attach/evolve/Boss + attack kill the averaged rollout can dilute or miss.
    Opponent-free by construction: a real this-turn lethal completes before they
    move. Called per determinization; choose_action only trusts a lethal that
    holds in ALL of them (a hand+board kill, not a phantom needing a prized card)."""
    cur = state.observation.current
    if cur is None:
        return False
    if cur.result == me:
        return True
    if cur.result >= 0 or cur.yourIndex != me:   # terminal-not-win, or turn passed
        return False
    if budget[0] <= 0 or time.monotonic() > deadline:
        return False
    obs_d = asdict(state.observation)
    select = obs_d.get("select")
    if select is None:
        return False
    # Branch over MAIN options; for forced sub-selects take the heuristic's one line.
    if select.get("type") == policy.SelectType.MAIN:
        choices = [[i] for i in range(min(len(select["option"]), LETHAL_BRANCH))]
    else:
        choices = [policy.choose(obs_d)]
    for ch in choices:
        budget[0] -= 1
        if budget[0] < 0:
            return False
        try:
            child = search_step(state.searchId, ch)
        except Exception:  # noqa: BLE001
            continue
        try:
            if _find_lethal(child, me, deadline, budget):
                return True
        finally:
            try:
                search_release(child.searchId)
            except Exception:  # noqa: BLE001
                pass
    return False


def choose_action(obs: dict, full_deck: list[int], rng: random.Random) -> list[int] | None:
    """Search-based choice for a branching MAIN decision. Returns a 1-element
    index list, or None to signal 'use the heuristic instead'."""
    if not ENABLED:
        return None
    global _IS_RAMP
    _IS_RAMP = _ENGINE in full_deck      # Cinderace ramp shell? -> ramp-tune value()
    STATS["calls"] += 1
    select = obs.get("select")
    if select is None or select.get("type") != policy.SelectType.MAIN:
        STATS["not_main"] += 1
        return None
    options = select["option"]
    if len(options) < 2:
        STATS["not_main"] += 1
        return None

    me = obs["current"]["yourIndex"]
    n = min(len(options), MAX_BRANCH)
    deadline = time.monotonic() + MOVE_BUDGET_S
    totals = [0.0] * n
    counts = [0] * n
    did_search = False

    # Finish mode gate: a "win THIS turn" only exists when the opponent is near
    # their last prizes, so only spend budget probing for lethal then (free early).
    opp_prizes = len(obs["current"]["players"][1 - me]["prize"])
    try_lethal = opp_prizes <= 3 and not os.environ.get("NO_LETHAL")
    lethal_hits = [0] * n

    for _d in range(DETERMINIZATIONS):
        if time.monotonic() > deadline:
            break
        try:
            root = begin(obs, full_deck, rng)   # a fresh imagined opponent
        except Exception as e:  # noqa: BLE001
            STATS["begin_raise"] += 1
            STATS["last_err"] = f"{type(e).__name__}: {e}"
            continue
        if root is None:
            STATS["begin_none"] += 1
            break
        did_search = True
        for i in range(n):
            try:
                child = search_step(root.searchId, [i])
                if try_lethal and _find_lethal(child, me, deadline, [LETHAL_NODES]):
                    lethal_hits[i] += 1
                v = _rollout(child, me, deadline)
                search_release(child.searchId)
            except Exception:  # noqa: BLE001
                continue
            totals[i] += v
            counts[i] += 1
            if time.monotonic() > deadline:
                break
        try:
            search_end()
        except Exception:  # noqa: BLE001
            pass

    if not did_search:
        return None
    STATS["searched"] += 1

    # Finish mode: commit to a move that wins THIS turn in EVERY determinization that
    # evaluated it (>=2). Robust across imagined worlds => a hand+board kill, not a
    # phantom needing a card that's really prized. Overrides the heuristic: the
    # averaged rollout can rank a "safe" setup over a real lethal (a win in 1 of 3
    # determinizations gets averaged down). "Normal turns by rules, winning turns
    # verified by search." -- the 1250 author's Finish mode.
    for i in range(n):
        if counts[i] >= 2 and lethal_hits[i] == counts[i]:
            STATS["lethal"] = STATS.get("lethal", 0) + 1
            return [i]

    # Average value per option; options never evaluated are skipped.
    # Tie-break toward ATTACK: when developing another bench mon and attacking
    # score ~equally (the short horizon can't see the chip payoff, so the leaf
    # values saturate), index order otherwise picks develop -> we durdle, build a
    # full bench, take 0 prizes and get out-paced (the #1 real-ladder loss). A tiny
    # nudge below any real value gap breaks those ties toward making progress
    # (attacking starts trading, which ALSO arms the Trevenant Revenge combo).
    # ponytail: epsilon < real value gaps (hundreds); only flips genuine ties/noise.
    ATTACK = policy.OptionType.ATTACK
    best_i, best_v = None, float("-inf")
    for i in range(n):
        if counts[i] == 0:
            continue
        avg = totals[i] / counts[i]
        if options[i].get("type") == ATTACK:
            avg += 3.0
        if avg > best_v:
            best_v, best_i = avg, i
    if os.environ.get("SEARCH_DEBUG"):
        scored = [(options[i].get("type"), round(totals[i] / counts[i], 1))
                  for i in range(n) if counts[i]]
        with open("/app/search_debug.log", "a") as f:
            f.write(f"pick idx{best_i} type{options[best_i].get('type')} | {scored}\n")
    return [best_i] if best_i is not None else None
